Please follow the below instructions to run the code error free. 

1) Put the files 

    - train.csv
    - test.csv

into the data directory. 


2) Run main.py 

The code generates a submission file for the 3 provided classifiers

    - RandomForestClassifier
    - HistGradientBoostingClassifier
    - SVC

The best performances on the public score were achieved using
SVC and HistGradientBoostingClassifier. Please, use these two
.csv files from the directory ./data/submit for the test against
the private data set. You can find the files easily by inspecting 
the .csv filenames. 


Thanks for your consideration. 

